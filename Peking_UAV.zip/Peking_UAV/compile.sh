cd ~/bearing_ws
rm -r -f build/lib/formation
scp -r ~/bearing_ws/src/formation chenyuda@192.168.0.112:/home/chenyuda/old_code
rm -r -f src/formation
scp -r chenyuda@192.168.0.112:/home/chenyuda/formation ~/bearing_ws/src/
catkin_make --pkg formation
source devel/setup.bash
roslaunch formation realFly.launch


